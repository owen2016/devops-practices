package com.example.hello;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootHelloApplicationTests {

	@Test
	void contextLoads() {
	}

}

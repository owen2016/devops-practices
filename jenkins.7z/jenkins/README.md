# Jenkins Pipeline

Jenkins 1.0 只能通过UI界面手动操作来“描述”流水线; Jenkins 2.0 开始支持pipeline as code.

所以这里主要存放 jenkins pipeline demo 以及jenkins pipeline 开发有关的规则和注意事项，对于相关知识这里不做解释。

## Pipeline 开发原则
1. 统一要求必须使用pipeline来代替UI界面手动操作

2. 所有pipeline 开发产出（jenkinfile,dockerfile,shell script,etc）遵循下面结构和项目业务代码放在一个代码仓库，CI/CD pipeline本身就是项目的组成部分，这样便于pipeline跟踪




4. 让构建尽量与环境无关 （任何的工具、环境依赖都能**自动化&可重复**）

## pipeline 命名

## Pipeline Demo

    - multibranch-pipeline





